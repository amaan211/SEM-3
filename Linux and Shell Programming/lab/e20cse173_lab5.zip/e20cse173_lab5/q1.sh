#!/bin/bash


echo "Enter n:"
read n 
i=0


echo "Enter numbers:"

while [ $i -lt $n ]
do
	read a[$i]
	i=`expr $i + 1`
done

echo "Output :"

i=0
len=$(($n/2))


while [ $i -lt $len ] 
do

max=${a[0]}
min=${a[0]} 


	for ele in ${a[@]}
	do

		if [ $max -lt $ele ]
		then 
			max=$ele
		elif [ $min -gt $ele ]
		then
			min=$ele
		fi

	done

	echo -n "$max "
	echo -n "$min "
	
	
	a=( "${a[@]/$min}" )
	a=( "${a[@]/$max}" )
	
	j=0
	
	for element in ${a[@]}
	do
		a1[$j]=$element
		((++j))
	done
	
	
	a=("${a1[@]}")
	
	i=`expr $i + 1`
	
done
echo ""
