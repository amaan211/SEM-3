#!/bin/bash


value=`awk 'NR > 1 && NR < 23 {print $0}' pingreply.txt | awk '{print $6}' | awk 'BEGIN {FS = "="} {print $2}'`


for all in $value
do

	if [ $((all%2)) -eq 0 ]
	then
		
		awk -v val="icmp_seq=$all" 'NR > 1 && NR < 23 && $6 == val {print $0}' pingreply.txt | cat >> evenpingreply.txt
	else
		awk -v val="icmp_seq=$all" 'NR > 1 && NR < 23 && $6 == val {print $0}' pingreply.txt | cat >> oddpingreply.txt
	fi
done


echo ""

timeEven=`awk '{print $0}' evenpingreply.txt | awk '{print $8}' | awk 'BEGIN {FS = "="} {print $2}'`

timeOdd=`awk '{print $0}' oddpingreply.txt | awk '{print $8}' | awk 'BEGIN {FS = "="} {print $2}'`

sumEven=0
countEven=0
sumOdd=0
countOdd=0

for time in $timeEven
do
	sumEven=`echo $sumEven + $time | bc`
	countEven=`expr $countEven + 1`
done

for time in $timeOdd
do
	sumOdd=`echo $sumOdd + $time | bc`
	countOdd=`expr $countOdd + 1`
done

avgOdd=$(echo "scale=2; $sumOdd/$countOdd" | bc)

avgEven=$(echo "scale=2; $sumEven/$countEven" | bc)



echo -n "Greater of the two is "

if [ `echo $avgOdd '>' $avgEven | bc` -eq 1 ]
then
	echo odd ping reply and its value is: $avgOdd ms
elif [ `echo $avgOdd '<' $avgEven | bc` -eq 1 ]
then
	echo even ping reply and its value is: $avgEven ms
else
	echo both are equal and their value is : $avgEven ms

fi












