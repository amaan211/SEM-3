#!/bin/bash
                                                           

times=`awk 'NR > 1 && NR < 23 {print $0}' pingreply.txt | awk '{print $8}' | awk 'BEGIN {FS = "="} {print $2}'`

maxTime=0
minTime=1000


for time in $times
do
	if (( $(bc <<< "$time > $maxTime") ))
	then
		maxTime=`echo $time | bc`
			
	elif (( $(bc <<< "$minTime > $time") ))
	then
		minTime=`echo $time | bc`

	fi
done

echo "Maximum RTT is for "
awk -v val="time=$maxTime" 'NR > 1 && NR < 23 && $8 == val {print $6}' pingreply.txt
echo ""
echo "Minimum RTT is for " 
awk -v val="time=$minTime" 'NR > 1 && NR < 23 && $8 == val {print $6}' pingreply.txt
echo "" 
