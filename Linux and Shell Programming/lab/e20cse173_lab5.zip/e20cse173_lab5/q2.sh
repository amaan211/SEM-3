#!/bin/bash


echo ...
ping -c 20 www.bennett.edu.in | cat > pingreply.txt                                                                



value=`awk 'NR > 1 && NR < 23 {print $0}' pingreply.txt | awk '{print $6}' | awk 'BEGIN {FS = "="} {print $2}'`


for all in $value
do

	if [ $((all%2)) -ne 0 ]
	then
		
		awk -v val="icmp_seq=$all" 'NR > 1 && NR < 23 && $6 == val {print $0}' pingreply.txt
	fi
done
echo done
echo ""
